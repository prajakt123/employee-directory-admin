ALTER TABLE `Contact`
	MODIFY `Contact_type_id` VARCHAR(8) NOT NULL;
