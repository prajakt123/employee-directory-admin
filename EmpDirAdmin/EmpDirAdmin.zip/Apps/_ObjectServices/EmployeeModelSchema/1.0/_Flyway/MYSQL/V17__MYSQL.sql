ALTER TABLE `Employee`
	MODIFY `Last_name` VARCHAR(32);
